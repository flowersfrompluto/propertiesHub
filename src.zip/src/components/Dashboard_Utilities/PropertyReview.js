import React from 'react'

const PropertyReview = () => {
  return (
    <div>
      <h1>Property Review</h1>
    </div>
  )
}

export default PropertyReview
