import React from 'react'

const Wishlist = () => {
  return (
    <div>
      <h1>Wish List</h1>
    </div>
  )
}

export default Wishlist
