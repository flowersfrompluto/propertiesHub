import React from 'react'
import { Outlet } from 'react-router-dom'


const Create_Update_Property_Form = () => {
  return (
    <div>
      <Outlet/>
    </div>
  )
}

export default Create_Update_Property_Form
