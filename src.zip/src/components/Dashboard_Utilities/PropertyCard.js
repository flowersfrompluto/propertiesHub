import React from 'react'

const PropertyCard = (props) => {
    const {propertyImage, propertyPrice, propertyLocation} = props
  return (
    <div>
      
    </div>
  )
}

export default PropertyCard
